package board;

public enum BoardRows {
    PLAYER_TWO_BACK, PLAYER_TWO_FRONT, PLAYER_ONE_FRONT, PLAYER_ONE_BACK
}
