package cards.minions;

public enum MinionRow {
    FRONT, BACK
}
