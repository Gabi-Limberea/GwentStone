package cards;

public enum CardAttackStatus {
    HAS_ATTACKED, HAS_NOT_ATTACKED
}
